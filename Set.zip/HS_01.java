import java.util.HashSet;;
import java.util.Iterator;

class HashTest{

    HashSet<String> H1=new HashSet<String>();

    HashSet saveCountryNames(String countryName){
        H1.add(countryName);
        return H1;
    }

    String getCountry(String countryName){
        String countryName1=countryName.trim();
        String res=null;
        Iterator itr=H1.iterator();
        while(itr.hasNext()){
            if(itr.next().equals(countryName1)){
                res=countryName1;
            }
            
        }
        return res;
    }

    public static void main(String[] args) {

        HashTest hashTest=new HashTest();
        
        hashTest.saveCountryNames("India");
        hashTest.saveCountryNames("Japan");
        hashTest.saveCountryNames("Canada");

        System.out.println(hashTest.getCountry("India"));  // returns India
        System.out.println(hashTest.getCountry("Canada")); // returns Canada
        System.out.println(hashTest.getCountry("Japan"));//   returns Japan
        System.out.println(hashTest.getCountry("USA"));  // returns null

    }
}