import java.util.HashSet;
import java.util.Iterator;
class Sample{
    public static void main(String[] args) {
        HashSet empSet=new HashSet();
        empSet.add("Akash");
        empSet.add("Anam");
        empSet.add("Alka");
        empSet.add("Shubham");
        empSet.add("Navneet");
        empSet.add("Adarsh");
        Iterator itr=empSet.iterator();
        while(itr.hasNext())
        System.out.println(itr.next());
    }
}