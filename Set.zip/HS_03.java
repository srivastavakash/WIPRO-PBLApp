import java.util.TreeSet;
import java.util.Iterator;
import java.util.TreeSet;

class Sample{

    public static void main(String[] args) {

        TreeSet<String> tSet=new TreeSet<String>();
        TreeSet<String> treeReverse= new TreeSet<String>();
        tSet.add("1");
        tSet.add("2");
        tSet.add("3");
        tSet.add(new String("4"));
        tSet.add("5");
        tSet.add("6");
        tSet.add("7");
        tSet.add("8");
        tSet.add("9");
        tSet.add("0");
        Iterator iterator;
        iterator=tSet.iterator();
        while (iterator.hasNext()) {
               System.out.print(iterator.next() + " ");
            }
        // creating reverse set
        treeReverse= new TreeSet<String>();
        treeReverse = (TreeSet)tSet.descendingSet();
      
            // create descending set
            iterator = treeReverse.iterator();
      
            // displaying the Tree set data
            System.out.println("\nTree set data in reverse order: ");     
            
            while (iterator.hasNext()) {
               System.out.print(iterator.next() + " ");
            }

            // checking whether a particular element exists or not
            String srch="8";
            if(tSet.contains(srch));
            System.out.println("\nElement "+srch+" found");
            /* while(iterator.hasNext()){
                if(iterator.next()=="8");
                System.out.println("Element "+srch+"found");
            } */

    }
}