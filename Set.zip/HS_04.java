import java.util.TreeSet;
import java.util.Iterator;

class Sample{

    TreeSet<String> tSet=new TreeSet<String>();

    TreeSet saveCountryNames(String countryName){
        tSet.add(countryName);
        return tSet;
    }

    String getCountry(String countryName){
        String countryName1=countryName.trim();
        String res=null;
        if(tSet.contains(countryName1))
        res=countryName;
        return res;
    }

    public static void main(String[] args) {

        Sample sample=new Sample();
        
        sample.saveCountryNames("India");
        sample.saveCountryNames("Japan");
        sample.saveCountryNames("Canada");

        System.out.println(sample.getCountry("India"));  // returns India
        System.out.println(sample.getCountry("Canada")); // returns Canada
        System.out.println(sample.getCountry("Japan"));//   returns Japan
        System.out.println(sample.getCountry("USA"));  // returns null

    }
}