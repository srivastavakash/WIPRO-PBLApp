import java.io.*;
import java.util.Scanner;


 class Count {
    public static void main(String[] args)throws IOException
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the file name");
        String fileName =sc.nextLine();
        System.out.println("Enter the character to be counted");
        char ch=sc.next().charAt(0);
        String line = "";
        Scanner scanner = new Scanner(new FileReader(fileName));
        int counter = 0;
        try {

          while ( scanner.hasNextLine() ){
            line = scanner.nextLine();
            

            for( int i=0; i<line.length(); i++ ) {
                if( line.charAt(i) == ch ) {
                    counter++; 

                } 


            }

             System.out.println(counter);   
          }
        }
        finally {

            System.out.println("File ''"+fileName+"'' has "+counter+" instances of letter'"+ch+"'.");

          scanner.close();


    }}}