import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;

 class WordCount {
	public static void main(String[] args) throws Exception  {
		Scanner sc=new Scanner(System.in);
		File input=new File("inputFile.txt");
		String[] words;
		int count=0;
		try {
			FileInputStream fin=new FileInputStream(input);
			byte[] b =new byte[fin.available()];
			fin.read(b);
			String a = new String(b);
			StringTokenizer st1=new StringTokenizer(a);
			int tokens = st1.countTokens();
			words=new String[tokens];
			//Unique words seperate
			for(int j=0;j<tokens;j++) {
				String t=st1.nextToken().trim();
				
				 if(count==0) {
					 words[count]=t;
					 count++;
					 }else {
						int flag=0;
						 for(int k=0;k<count;k++) {
							 if(words[k].trim().equals(t)) {
							     
								 flag=1;
								 break;
							 }							 
						 }
						 if(flag!=1) {
						     
								 words[count]=t;
								 count++;
							 }
					 }
				
			}
			
			String temp1;
			//Sorting
			for(int k=0;k<count;k++) {
				for(int l=0;l<count-k-1;l++) {
					if(words[l].compareTo(words[l+1])>0){
						temp1=words[l];
						words[l]=words[l+1];
						words[l+1]=temp1;
						
					}
				}
			}
	
		
			
			for(int k=0;k<count;k++) {
				StringTokenizer st2= new StringTokenizer(a);
				int token1=st2.countTokens();
				int counter=0;
				for(int l=0; l<token1;l++) {
					if(words[k].equals(st2.nextToken())){
						counter++;
					}
					
				}
				System.out.println(words[k] + ":" + counter);
			}
			fin.close();	
	}catch(IOException ex) {
		System.out.println(ex);}
	
	finally {
		sc.close();
		
	}

  }
}
