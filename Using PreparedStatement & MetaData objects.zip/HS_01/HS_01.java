import java.sql.*;
class JDBCCalls{
        public static void main(String[] args) throws SQLException {
        DAOClass dc=new DAOClass();
        int opr=0;
        int sid=0;
        String name="";
        String standard="";
        String date="";
        int fee=0;
        opr=Integer.parseInt(args[0]);
        sid=Integer.parseInt(args[1]);
        name=args[2];
        standard=args[3];
        date=args[4];
        fee=Integer.parseInt(args[5]);
        switch(opr){
            case 1:
                dc.insert(sid,name,standard,date,fee);
                break;
            case 2:
                dc.delete(sid);
                break;

            case 4:
                dc.showTable();
            default:
            System.out.println("");
        }
        
    }
}