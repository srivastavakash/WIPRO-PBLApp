import java.sql.*;
public class DAOClass{
    public static void main(String[] args) throws Exception {
      connect();
    }
    public static void connect(){
    Connection con=null;
        try {
                con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcll","hr","hr");
        } 
        catch (Exception e) {
             e.printStackTrace();
        }
        if(con!=null)
            System.out.println("Connection Established successfully");
        else
            System.out.println("Connection could not be established");
     }

      public static Connection connection() throws SQLException{
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcll", "hr", "hr");
        return con;
   }
 /*
   public boolean delete(int rollno) {
    String sql = "DELETE stdnt WHERE rollno = ?";
    
    try {
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, rollno);
        pstmt.executeUpdate();
        
        return true;
    } catch (SQLException e) {
        return false;
    }
   }*/

public boolean modify(int rollno, int fee) {
    String sql = "UPDATE stdnt SET fee = ? WHERE rollno = ?";
        Connection con=null;    
        PreparedStatement pstmt=null;
    try {
        con=connection();
        pstmt = con.prepareStatement(sql);
        pstmt.setInt(1, fee);
        pstmt.setInt(2, rollno);
        pstmt.executeUpdate();
        
        return true;
    } catch (SQLException e) {
        return false;
    }
}

   void insert(int id,String name,String standard,String date,int fee) throws SQLException{
        int sid=id;
        String sname=name;
        String std=standard;
        String sdate=date;
        int sfee=fee;
        Connection conn=null;
        PreparedStatement ps=null;
        int rs=0;
    try{
        conn=connection();
        String query="insert into student values(?,?,?,?,?)";
        ps=conn.prepareStatement(query);
        ps.setInt(1,sid);
        ps.setString(2,sname);
        ps.setString(3,std);
        ps.setString(4,sdate);
        ps.setInt(5,sfee);
        rs=ps.executeUpdate();
        if(rs>0)
         System.out.println("Inserted Sucessfully");
        }
    catch(SQLException se){
        se.printStackTrace();
        }
    finally {
            ps.close();
            conn.close();
          }
   }

   public void delete (int roll) throws SQLException{
        int rollno=roll;
        Connection conn=null;
        PreparedStatement ps=null;
        int rs=0;
        try{
        conn=connection();
        String query="delete from student where Rollno = ?";
        ps=conn.prepareStatement(query);
        ps.setInt(1,rollno);
        rs=ps.executeUpdate();
        if(rs>0)
        System.out.println("Deleted Sucessfully");
        }
        catch(SQLException se){
            se.printStackTrace();
        }

   }
   public boolean showTable(int rollno) {
    String sql = "SELECT * FROM student WHERE rollno = ?";
    
    try {
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, rollno);
        ResultSet rs = pstmt.executeQuery();
        ResultSetMetaData rsmd = rs.getMetaData();
        
        while (rs.next()) {
            StringBuilder sb = new StringBuilder();
            
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                String colName = rsmd.getColumnName(i);
                
                sb.append(rs.getObject(colName));
                if (i != rsmd.getColumnCount()) sb.append(", ");
            }
            System.out.println(sb);
        }
        
        return true;
    } catch (SQLException e) {
        return false;
    }
}
   void showTable(){
    Connection conn=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    try{
    conn=connection();
    String query="SELECT * FROM student";
    ps=conn.prepareStatement(query);        
    rs=ps.executeQuery();
    System.out.format("%-15s %-15s %-10s %-15 %-15s\n","Roll No","StudentName","Standard","Date_Of_Birth","Fees");
    while(rs.next()){
        System.out.format("%-15s %-15s %-10s %-15 %-15s\n",rs.getInt("Rollno"),rs.getString("StudentName"),rs.getString("Standard"),rs.getString("Date-Of_Birth"),rs.getString("Fees"));
    }
    }
    catch(SQLException se){
        se.printStackTrace();
    }

   }

}