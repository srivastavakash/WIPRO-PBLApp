import java.sql.*;
public class JDBCCalls {

	public static void main(String[] args) {
		int opr = Integer.parseInt(args[0]);
		DAOClass dao = new DAOClass();
		
		switch (opr) {
		case 1: // insert: java JDBCCalls 1 101 Ajit IV 20-Nov-2001 4000
			int rollno = Integer.parseInt(args[1]);
			String name = args[2];
			String grade = args[3];
			String dob = args[4];
			int fee = Integer.parseInt(args[5]);
			try{
			dao.insert(rollno, name, grade, dob, fee);
			}
			catch(SQLException se){
				se.printStackTrace();
			}
			break;
			
		case 2: // delete: java JDBCCalls 2 101 
			rollno = Integer.parseInt(args[1]);
			try{
			dao.delete(rollno);
			}
			catch(SQLException se){
				se.printStackTrace();
			}
			break;
			
		case 3: // update: java JDBCCalls 3 101 4500
			rollno = Integer.parseInt(args[1]);
			fee = Integer.parseInt(args[2]);
			if (dao.modify(rollno, fee))
				System.out.println("Modified successfully");
			else 
				System.out.println("Modification error");
			break;
			
		case 4: // select: java JDBCCalls 4 101
			try {
				if(args.length==2){
				rollno = Integer.parseInt(args[1]);
				dao.showTable(rollno)
				}
				else
				dao.showTable();
				break;
			} catch (Exception e) {
				dao.showTable();
				break;
			}
			
			
		}

	}

}
