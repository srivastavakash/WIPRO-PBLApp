import java.sql.*;
class TestConnection{
    public static void main(String[] args) throws Exception {
        
        Connection con=null;
            
        try {
             Class.forName("Oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcll", "system", "dreamer");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(con!=null)
        System.out.println("Connection Established successfully");
        else
        System.out.println("Connection could not be established");
    }
}