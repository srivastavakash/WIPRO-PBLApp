SELECT last_name,job_id,hire_date FROM employees 
    WHERE last_name='Motto' OR last_name='Taylor' ORDER BY hire_date;