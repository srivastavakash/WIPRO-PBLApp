CREATE OR REPLACE PROCEDURE calculate_salary (
	p_empno IN employees.employee_id % TYPE,
	p_comm IN employees.commission_pct % TYPE,
	p_sal IN emp.salary % TYPE,
	p_percent IN NUMBER
) 
IS 
	gross_salary NUMBER;
	net_salary NUMBER;
	it NUMBER;
BEGIN 

	gross_salary := p_sal + p_comm;
	
	IF p_comm IS NULL THEN
		it := gross_salary * 10 / 100;
	ELSE IF p_comm < 500 THEN
		it := gross_salary * 15 / 100;
	ELSE
		it := gross_salary * 20 / 100;
	END IF;

	net_salary := gross_salary - it;

	UPDATE emp SET sal = sal * ( 1 + p_percent/ 100 ) 
	WHERE empno = p_id; 

    END IF;
END calculate_salary;
/
commit;