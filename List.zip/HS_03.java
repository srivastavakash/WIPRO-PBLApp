import java.util.ArrayList;
import java.util.Iterator;
class Sample{
    public static void main(String[] args) {
        ArrayList<String> list=new ArrayList<>();
        list.add("String one");
        list.add("String two");
        list.add("String three");
        list.add("String four");
        printAll(list);
    }
    static void printAll(ArrayList<String> al){
        Iterator i=al.iterator();
        while(i.hasNext())
          System.out.println(i.next());
    }
}