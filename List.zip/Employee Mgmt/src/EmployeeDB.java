import java.util.*;

public class EmployeeDB {
	
    ArrayList<Employee> list =new ArrayList<Employee>();
    Iterator<Employee> itr=list.iterator();
    boolean addEmployee(Employee e) {
    	boolean status= list.add(e);
    	return status;
    	
	}
    
    
    boolean  deleteEmployee(int empIdd) {
    	boolean status=false;
    	while(itr.hasNext()) {
    		Employee emp =(Employee)itr.next();
    		if(emp.getEmpId()==empIdd) {
    			list.remove(emp);
    			status=true;
    			break;
    		}
    	}
    	return status;
    }
    
    String showPaySlip(int empIdd) {
    	String paySlip=null;    	
    	for(Employee emp:list) {
    		if(emp.getEmpId()==empIdd) {
    			paySlip=emp.getEmpId() +" " +emp.getEmpName()+" " +emp.getSalary();
    		}
    	}
    	
    	return paySlip;
    }
}
