
public class TestEmployee {

	public static void main(String[] args) {
			EmployeeDB empDetails=new EmployeeDB();
			
			Employee e=new Employee(1,"Akash","srivastavakash@outlook.com","male",26666.66f);
			empDetails.addEmployee(e);
			Employee e1=new Employee(2,"Shubham","cool.shubhamsharma1111@gmail.com","male",26667.6f);
			empDetails.addEmployee(e1);
			Employee e2=new Employee(3,"Navneet","cool.njs@gmail.com","male",26667.6f);
			empDetails.addEmployee(e2);
			e.getEmployeeDetails();
			e1.getEmployeeDetails();
			e2.getEmployeeDetails();
			System.out.println(empDetails.showPaySlip(1));;
				
	}

}
