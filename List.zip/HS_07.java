import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;

class Employee {
    
        int empId;
        String empName,email,gender;
        float salary;
        Employee(int empId, String empName, String email, String gender, float salary) {
            this.empId = empId;
            this.empName = empName;
            this.email = email;
            this.gender = gender;
            this.salary = salary;
        }

        public String toString(){
            return "\nEmployee Id :"+this.empId+"\n Employee Name :"+this.empName+"\n Employee email :"+this.email+"\n Employee Gender :"+this.gender+"\n Employee Salary :"+this.salary+"\n-------------------------------------------------------";
        }
}
class Sample{
    public static void main(String[] args) {
        Vector<Employee> v= new Vector<Employee>();
        v.addElement(new Employee(101, "Akash", "srivastavakash@outlook.com", "male", 10000));
        v.addElement(new Employee(102, "Anam", "aam@outlook.com", "female", 12000));
        v.addElement(new Employee(103, "Adarsh", "adarshsrivastav@outlook.com", "male", 13000));
        v.addElement(new Employee(104, "Shubham", "shubhamsharma@outlook.com", "male", 15000));
        v.addElement(new Employee(105, "Alka", "dubeyalka@outlook.com", "female", 14000));
        v.addElement(new Employee(106, "Anjali", "anjaligautam@outlook.com", "female", 17000));
        // Using Iterator
        System.out.println("Using Iterator :");
        Iterator itr=v.iterator();
        while(itr.hasNext())
        System.out.println(itr.next());

        // Using Enumeration
        System.out.println("Using Enumeration :");
        Enumeration en=v.elements();
        while(en.hasMoreElements())
        System.out.println((Employee)en.nextElement());

    }
}