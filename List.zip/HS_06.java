import java.util.Vector;;
class Sample{
    public static void main(String[] args) {
        Vector months = new Vector();
        months.addElement("January");
        months.addElement("February");
        months.addElement("March");
        months.addElement("April");
        months.addElement("May");
        months.addElement("June");
        months.addElement("July");
        months.addElement("August");
        months.addElement("September");
        months.addElement("October");
        months.addElement("November");
        months.addElement("December");
        System.out.println(months);
    }
}