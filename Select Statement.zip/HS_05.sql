SELECT (LAST_NAME || ', ' || JOB_ID )"Employee and Title"
  FROM EMPLOYEES;