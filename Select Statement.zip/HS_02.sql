select employee_id,last_name,job_id,hire_date
        "STARTDATE"
        from employees;