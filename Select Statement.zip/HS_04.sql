select employee_id "EMP #",first_name||last_name "EMPLOYEE",job_id "JOB",hire_date "Hire Date" 
from employees;