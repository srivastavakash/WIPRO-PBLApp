CREATE TABLE EMP(
  ID NUMBER(7),
  LAST_NAME VARCHAR2(25) NOT NULL,
  FIRST_NAME VARCHAR2(25),
  DEPT_ID NUMBER(7),
  PRIMARY KEY (ID),
  FOREIGN KEY (ID) REFERENCES DEPT(DEPT_ID));

INSERT INTO emp(id,last_name,first_name,dept_id)
    VALUES(101,'Ram','Sundar',10);
  
INSERT INTO emp(id,last_name,first_name,dept_id)
    VALUES(101,'Ram','Krishna',20);

INSERT INTO emp(id,last_name,first_name,dept_id)
    VALUES(103,'Gopi','null',40);


INSERT INTO emp(id,last_name,first_name,dept_id)
    VALUES(103,'Gopi','null',40);