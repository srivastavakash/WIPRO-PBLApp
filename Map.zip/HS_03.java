import java.util.Properties;
import java.util.Set;
import java.util.Iterator;

class PropertiesClass{
    public static void main(String[] args) {
        Properties capitals=new Properties();
        Set states;
        String str;
        capitals.put("Uttar Pradesh", "Lucknow");
        capitals.put("Maharashtra", "Mumbai");
        capitals.put("Rajasthan", "Jaipur");
        capitals.put("Bhar", "Patna");
        capitals.put("Punjab", "Chandigarh");
        capitals.put("J & K", "Sri Nagar");
        capitals.put("Sikkim", "Gangtok");
        capitals.put("Madhya Pradesh", "Bhopal");
        capitals.put("Goa", "Panaji");
        states = capitals.keySet();   
        Iterator itr = states.iterator();
        while(itr.hasNext()) {
           str = (String) itr.next();
           System.out.println("The capital of " + str + " is " + 
              capitals.getProperty(str) + ".");
        }     
        System.out.println();

    }
}