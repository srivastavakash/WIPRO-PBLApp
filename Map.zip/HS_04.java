import java.util.HashMap; 
import java.util.Map; 
class Sample{

    public static void main(String[] args) {
        HashMap<String,Long> contacts=new HashMap<String,Long>();
        contacts.put("Akash",7985974185l);
        contacts.put("Anam",8423847490l);
        contacts.put("Adarsh",7985974185l);
        contacts.put("Shubham",8423847490l);
        contacts.put("Akash",7985974185l);
        contacts.put("Anam",8423847490l);
        System.out.println(contacts);
    }

}