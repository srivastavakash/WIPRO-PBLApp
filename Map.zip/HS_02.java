import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

class Sample{
    public static void main(String[] args) {
        HashMap<String,String> hashmap=new HashMap<String,String>();
        hashmap.put("India","Delhi");
        hashmap.put("US", "Washington DC");
        hashmap.put("Japan", "Tokyo");
        hashmap.put("Russia","Moscow");
        hashmap.put("Egypt","Cairo");
        hashmap.put("UK", "London");
        if(hashmap.containsKey("Russia"))
           System.out.println("key Russia found ");
        else
           System.out.println("key Russia not found");
        if(hashmap.containsValue("London"))
           System.out.println("Value London found");
        else
           System.out.println("Value London not found");

        System.out.println("Printing the HashMap using Iterator");
        Iterator<Map.Entry<String, String>> itr = hashmap.entrySet().iterator(); 
        while(itr.hasNext()){
        HashMap.Entry<String, String> entry = itr.next(); 
        System.out.println("Key = " + entry.getKey() +  
                            ", Value = " + entry.getValue()); 
        }
    }
}