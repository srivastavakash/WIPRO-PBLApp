import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Iterator;;
class CountryCapital{
    HashMap<String,String> M1=new HashMap<String,String>();
    //to save country-capital pairs into hashmap
    public HashMap saveCountryCapital(String countryName,String capitalName){
        M1.put(countryName, capitalName);

        return M1;
    }
   // method to get capital by country name
    String getCapital(String countryName){
            String capital=null;
            if (M1.containsKey(countryName))  
             capital = M1.get(countryName); 
            return capital;
        
    }
    // method to get country by capital name
    String getCountry(String capitalName){
        String country=null;
        for (Entry<String, String> entry : M1.entrySet()) {
            if (entry.getValue().equals(capitalName)) {
                country=entry.getKey();
            }
        }
    return country;
    
}
    // Method to Reverse and print the HashMap
    
     public HashMap reverseMap(HashMap<String,String> map){

        HashMap<String,String> M2 =new HashMap<String,String>();
        for (Entry<String, String> entry : M1.entrySet()) {
            //System.out.println(entry.getValue()+" : "+entry.getKey());
            M2.put(entry.getValue(), entry.getKey());
        }
        System.out.println("Capital"+"    "+"Country");
        Iterator<Entry<String, String>> it = M2.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> pair = (Map.Entry<String, String>) it.next();
			System.out.println(pair.getKey() + "     " + pair.getValue());
		}
        //System.out.println(M2);
        return M2;

    }

    // Method to create an ArrayList using Keys in the HashMap
       ArrayList createArrayList(HashMap<String,String> map){
           ArrayList<String> keyArray=new ArrayList<String>();
           Iterator<Entry<String, String>> it = map.entrySet().iterator();
           while (it.hasNext()) {
               Map.Entry<String, String> pair = (Map.Entry<String, String>) it.next();
               //System.out.println(pair.getKey() + "     " + pair.getValue());
               keyArray.add(pair.getKey());
           }
           return keyArray;
       }


    // General Method to Print HashMap

    void printMap(HashMap<String,String> map,String key,String value){

        System.out.println(key+"    "+value);
        Iterator<Entry<String, String>> it = M1.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> pair = (Map.Entry<String, String>) it.next();
			System.out.println(pair.getKey() + "     " + pair.getValue());
		}
    }

    public static void main(String[] args) {
        CountryCapital countryCapital = new CountryCapital();
        countryCapital.saveCountryCapital("India", "Delhi");
        countryCapital.saveCountryCapital("Japan", "Tokyo");
        countryCapital.saveCountryCapital("USA", "Washington-DC");
        countryCapital.saveCountryCapital("France", "Paris");
        countryCapital.printMap(countryCapital.M1,"Country","Capital");
        System.out.println(countryCapital.getCapital("India"));
        System.out.println(countryCapital.getCountry("Delhi"));
        HashMap<String,String> reverse=countryCapital.reverseMap(countryCapital.M1);
        System.out.println("The HashMap with Capital as key and Country as Value");
        countryCapital.printMap(reverse,"Capital","Country");
        System.out.println(countryCapital.createArrayList(countryCapital.M1));

    }
}   