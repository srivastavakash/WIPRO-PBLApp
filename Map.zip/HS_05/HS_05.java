/*
Implement the assignment 1 using TreeMap
 */



import java.util.HashMap;
import java.util.TreeMap;



public class Assignment5 {

	public static void main(String[] args) {
		CountyMap countryMap = new CountyMap();

		countryMap.saveCountryCapital("India", "Delhi");
		countryMap.saveCountryCapital("Japan", "Tokyo");
		countryMap.saveCountryCapital("USA", "Washington, D.C.");
		
		System.out.println(countryMap.getCapital("India"));
		System.out.println(countryMap.getCountry("Tokyo"));
		System.out.println(countryMap.toArrayList());
		
		TreeMap<String, String>M2 = CountyMap.swapKyeValue();
		System.out.println(M2);
	}

}
