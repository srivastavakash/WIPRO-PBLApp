import java.sql.*;
class myQuery1{
        public static void main(String[] args) throws Exception {
            Connection con=null;
            try {
                con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcll", "hr", "hr");
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            Statement stmt=con.createStatement();
            ResultSet rs =stmt.executeQuery("select * from employees where salary between 10000 and 20000");
            while(rs.next()){
                System.out.println(rs.getString("FIRST_NAME")+"\t"+rs.getString("JOB_ID")+"\t"+rs.getString("SALARY")+"\t"+rs.getString("COMMISSION_PCT"));           
            }
    

    }
}