
import java.sql.PreparedStatement;
import java.sql.*;
class myQuery{
    public static void main(String[] args) throws Exception {
        Connection con=null;
        try {
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcll", "hr", "hr");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(con!=null)
        System.out.println("Connection Established successfully");
        else
        System.out.println("Connection could not be established");
        Statement stmt=con.createStatement();
        ResultSet rs =stmt.executeQuery("select * from employees");
        while(rs.next()){
            System.out.println(rs.getInt(1)+" "+rs.getString("FIRST_NAME"));
        }


    }
}