INSERT INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES(205,'Shelley','Higgins',110,12000);
INSERT INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES(100,'Steven','King',90,24000);
INSERT INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES(101,'Neena','Kochhar',90,17000);
INSERT INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES(102,'Lex De','Haan',90,17000);
INSERT INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES(111,'Ismael','Sciarra',100,7700);
INSERT INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES(112,'Jose Manuel','Urmaan',100,7800);
INSERT INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES(205,'Herman','Baer',70,10000);



