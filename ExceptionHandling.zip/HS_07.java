class InvalidCountryException extends Exception{
    String str;
    InvalidCountryException(String str1){
        str=str1;
    }
    public String toString(){
        return str;
    }
}

class UserRegistration{
    static boolean registerUser(String username,String userCountry){
        if(userCountry!="India")
        return false;
        else
        return true;
    }
    public static void main(String[] args) {
        try {
            boolean flag;
            flag=registerUser("Mickey","India");
            if(!flag)
            throw new InvalidCountryException("User Outside India cannot be registered");
            else
            System.out.println("User Registration done successfully");
        } 
        catch (InvalidCountryException ice) {
            System.out.println(ice) ;
            System.exit(0);
        }
        
    }
}