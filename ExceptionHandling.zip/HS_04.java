
class MathOperation{
    public static void main(String[] args) {
       int array[]=new int[5];
       int sum=0,avg=0;
       boolean flag=false;
        try{
        for (int i = 0; i < 5; i++) {
            array[i]=Integer.parseInt(args[i]);
        }
        for (int var : array) {
            sum+=var;
        }
        avg=sum/5;
    }
    catch(NumberFormatException ne){
        System.out.println(ne.getClass().getName());
        System.exit(0);
    }
    catch(ArithmeticException ae){
        System.out.println(ae.getClass().getName());
        flag=true;

    }
    catch (ArrayIndexOutOfBoundsException e) {
            flag=true;
            System.out.println(e.getClass().getName());
        }
        if(!flag){
        System.out.println("The sum of all elements : "+sum);
        System.out.println("The average of all elements : "+avg);
        }
    }
}