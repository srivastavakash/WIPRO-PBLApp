import java.util.Scanner;
class Sample{
    public static void main(String[] args) {
        
        Scanner sc= new Scanner(System.in);
        double num1=sc.nextDouble();
        double num2=sc.nextDouble();

        try {

            double result=divide(num1, num2);
            if(num1==0||num2==0) throw new ArithmeticException("Division by zero");
            System.out.println(result);

        }
         catch (ArithmeticException ae) {

            System.out.println("Division by zero");
        }
    }
    static double divide(Double a,Double b) throws ArithmeticException {

        return a/b;
    }
}