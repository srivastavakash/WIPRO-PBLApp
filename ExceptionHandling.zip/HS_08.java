class MyException extends Exception{
    String str1;
    MyException(String str2) {
    str1=str2; 
    }
    public String toString(){
    return ("Exception: "+str1) ;
    }
    }
    class Tester{
    public static void main(String args[]){
    String name=args[0];
    int age=0;
    try{
        age=Integer.parseInt(args[1]);
        if(age<18 || age>60)
    throw new MyException("Age must be between 18 and 60");
    }
    catch(NumberFormatException ne){
        System.out.println("Invalid input");
        System.exit(0);
    }
    catch(MyException e){
    System.out.println("Exception Handler") ;
    System.out.println(e) ;
    System.exit(0);
    }
    System.out.println("Name : "+name+"\nAge  : "+age);
  }
}
    