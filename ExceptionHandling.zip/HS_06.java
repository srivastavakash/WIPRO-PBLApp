import java.util.InputMismatchException;
import java.util.Scanner;
class MyException extends Exception{
    String str1;
    MyException(String str2) {
    str1=str2;
    }
    public String toString(){
    return ("Exception: "+str1) ;
    }
    }
    class Tester{
    public static void main(String args[]){
    Scanner sc = new Scanner(System.in);
    String student[]=new String[2];
    int marks1[]=new int[3];
    int marks2[]=new int[3];
    System.out.println("Enter the names of two students");
    for (int i = 0; i < 2; i++) 
       student[i]=sc.nextLine();
    System.out.println("Enter the marks for "+student[0]);
   

    try{
        for (int i = 0; i < 3; i++)
             marks1[i]=sc.nextInt(); 
            System.out.println("Enter the marks for "+student[1]);
          for (int i = 0; i < 3; i++)          
                marks2[i]=sc.nextInt();    
          for (int i = 0; i < 3; i++) {
              if(marks1[i]<0 || marks1[i]>100 || marks2[i]<0 || marks2[i]>100 )
                 throw new MyException("Marks out of range: Please enter marks between 0 to 100");
          }
    }
    catch(InputMismatchException ie){
        System.out.println("Invalid input");
        System.exit(0);
    }
    catch(NumberFormatException ne){
        System.out.println("Invalid input");
        System.exit(0);
    }
    catch(MyException e){
    System.out.println(e) ;
    System.exit(0);
    }
    double avg1=(marks1[0]+marks1[1]+marks1[2])/3;
    double avg2=(marks2[0]+marks2[1]+marks2[2])/3;
    System.out.println("Name : "+student[0]+"  Average Marks  : "+avg1);
    System.out.println("Name : "+student[1]+"  Average Marks   : "+avg2);
  }
}
    