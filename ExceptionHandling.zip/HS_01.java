import java.util.Scanner;
class sample{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            int num=Integer.parseInt(sc.next());
            System.out.println("The square value is :"+num*num);
        } catch (NumberFormatException e) {
            System.out.println("Entered input is not a valid format for an integer.");
            
        }
        

    }
}