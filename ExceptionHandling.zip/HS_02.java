import java.util.Scanner;
class Sample{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements in the array");
        int len=sc.nextInt();
        int[] array=new int[len];
        System.out.println("Enter the elements in the array");
        for (int i = 0; i < len; i++) {
            array[i]=sc.nextInt();
        }
        System.out.println("Enter the index of array element you want to access");
        int index=sc.nextInt();
        try {
            System.out.println("The array element at index "+index+" = "+array[index]+"\n"+"The array element successfully accessed");
        } catch (ArrayIndexOutOfBoundsException e) {
            //TODO: handle exception
            System.out.println(e.getClass().getName());
        }
    }
}