import java.util.Scanner;
class Sample{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter two numbers");
        int num1=sc.nextInt();
        int num2=sc.nextInt();
        try {
            int quotient=num1/num2;
            System.out.println("The quotient of "+num1+"/"+num2+" ="+quotient);
        } catch (ArithmeticException ae) {
            System.out.println("DivideByZeroException caught");
        }
        finally{
                System.out.println("Inside Finally block");
        }
    }
}